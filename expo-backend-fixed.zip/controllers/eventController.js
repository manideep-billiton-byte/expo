const pool = require('../db');
const { v4: uuidv4 } = require('uuid');

const getEvents = async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM events ORDER BY created_at DESC');
        return res.json(result.rows);
    } catch (dbErr) {
        console.error('Database error in getEvents:', dbErr);
        return res.status(500).json({ error: 'Failed to fetch events', details: dbErr.message });
    }
};

const createEvent = async (req, res) => {
    console.log('[createEvent] Request received');
    const payload = req.body || {};
    console.log('[createEvent] Payload:', JSON.stringify(payload).substring(0, 200));

    try {
        // generate QR token and registration link
        console.log('[createEvent] Generating QR token...');
        const token = uuidv4();
        const base = process.env.REGISTRATION_BASE || process.env.INVITE_LINK_BASE || 'https://expo.example.com';
        const registration_link = `${base.replace(/\\/$ /, '')}/register/event/${token}`;
        console.log('[createEvent] Registration link:', registration_link);

        // Note: 'name' column exists for legacy reasons with NOT NULL constraint
        const eventName = payload.eventName || payload.event_name || 'Untitled Event';
        console.log('[createEvent] Event name:', eventName);

        const insertSql = `INSERT INTO events(
                name, event_name, description, event_type, event_mode, industry,
                organizer_name, contact_person, organizer_email, organizer_mobile,
                venue, city, state, country, start_date, end_date,
                registration, lead_capture, communication, qr_token, registration_link, status
            ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22) RETURNING *`;

        const values = [
            eventName, // for legacy 'name' column (NOT NULL)
            eventName, // for 'event_name' column
            payload.description || null,
            payload.eventType || payload.event_type || null,
            payload.eventMode || payload.event_mode || null,
            payload.industry || null,
            payload.organizerName || payload.organizer_name || null,
            payload.contactPerson || payload.contact_person || null,
            payload.organizerEmail || payload.organizer_email || null,
            payload.organizerMobile || payload.organizer_mobile || null,
            payload.venue || null,
            payload.city || null,
            payload.state || null,
            payload.country || null,
            payload.startDate || payload.start_date || null,
            payload.endDate || payload.end_date || null,
            payload.registration || {},
            payload.leadCapture || payload.lead_capture || {},
            payload.communication || {},
            token,
            registration_link,
            payload.status || 'Draft'
        ];

        console.log('[createEvent] Executing database query...');
        const result = await pool.query(insertSql, values);
        console.log('[createEvent] Query successful');

        const created = result.rows[0];
        console.log('[createEvent] Event created successfully:', created.id);
        return res.status(201).json(created);
    } catch (err) {
        console.error('[createEvent] ERROR:', err.message);
        console.error('[createEvent] ERROR stack:', err.stack);
        console.error('[createEvent] ERROR code:', err.code);
        return res.status(500).json({
            error: 'Failed to create event',
            details: err.message,
            code: err.code
        });
    }
};

module.exports = { getEvents, createEvent };