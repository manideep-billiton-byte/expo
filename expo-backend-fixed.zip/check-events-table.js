const pool = require('./db');

async function checkEventsTable() {
    try {
        console.log('Checking events table schema...');

        // Check if table exists
        const tableCheck = await pool.query(`
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema='public' AND table_name='events'
        `);

        if (tableCheck.rows.length === 0) {
            console.log('❌ events table does NOT exist!');
            return;
        }

        console.log('✅ events table exists');

        // Check columns
        const columns = await pool.query(`
            SELECT column_name, data_type, is_nullable, column_default
            FROM information_schema.columns
            WHERE table_name = 'events'
            ORDER BY ordinal_position
        `);

        console.log('\nColumns in events table:');
        console.log('------------------------');
        columns.rows.forEach(col => {
            console.log(`${col.column_name} (${col.data_type}) ${col.is_nullable === 'NO' ? 'NOT NULL' : 'NULL'}`);
        });

        // Check for 'name' column specifically
        const nameColumn = columns.rows.find(col => col.column_name === 'name');
        if (nameColumn) {
            console.log('\n✅ "name" column exists');
        } else {
            console.log('\n❌ "name" column is MISSING');
        }

        // Try a simple SELECT query
        console.log('\nTesting SELECT query...');
        const selectTest = await pool.query('SELECT COUNT(*) as count FROM events');
        console.log(`✅ SELECT works. Row count: ${selectTest.rows[0].count}`);

        console.log('\n✅ All diagnostic checks passed!');
        process.exit(0);

    } catch (err) {
        console.error('❌ ERROR:', err.message);
        console.error('Error code:', err.code);
        console.error('Error stack:', err.stack);
        process.exit(1);
    }
}

checkEventsTable();
